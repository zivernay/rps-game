Credits to the used media
- ## Rock
  [Photo by Pille  Kirsi](https://www.pexels.com/photo/macro-photo-of-a-rock-1093207/)

- ## Paper
  [Photo by COLYS HAT](https://www.pexels.com/photo/crumpled-paper-1587442/)

- ## Scissors
  [Photo by Jess Bailey Designs](https://www.pexels.com/photo/close-up-photography-scissors-755991/)

- # Winner
  [Photo by Nataliya Vaitkevich](https://www.pexels.com/photo/golden-statuette-and-stars-on-yellow-background-6532373/)
	1. <div style="width:100%;height:0;padding-bottom:38%;position:relative;"><iframe src="https://giphy.com/embed/LPfGHdZ7jRmja01dr3" width="100%" height="100%" style="position:absolute" frameBorder="0" class="giphy-embed" allowFullScreen></iframe></div><p><a href="https://giphy.com/gifs/beeinspiredclothing-bee-b33-inspired-LPfGHdZ7jRmja01dr3">via GIPHY</a></p>
	2. <div style="width:480px"><iframe allow="fullscreen" frameBorder="0" height="270" src="https://giphy.com/embed/Atx1IgqtSq7B5MB3BN/video" width="480"></iframe></div>
	3. <div style="width:100%;height:0;padding-bottom:83%;position:relative;"><iframe src="https://giphy.com/embed/JZdLY4pqggtfXbvxLh" width="100%" height="100%" style="position:absolute" frameBorder="0" class="giphy-embed" allowFullScreen></iframe></div><p><a href="https://giphy.com/gifs/theoffice-JZdLY4pqggtfXbvxLh">via GIPHY</a></p>
	4. <div style="width:100%;height:0;padding-bottom:56%;position:relative;"><iframe src="https://giphy.com/embed/Y3qaJQjDcbJPyK7kGk" width="100%" height="100%" style="position:absolute" frameBorder="0" class="giphy-embed" allowFullScreen></iframe></div><p><a href="https://giphy.com/gifs/DaveandBusters-winner-you-win-dave-and-busters-Y3qaJQjDcbJPyK7kGk">via GIPHY</a></p>

- # Loser
  [Photo by Shamia Casiano](https://www.pexels.com/photo/closeup-photography-of-loser-scrabble-letter-944737/)
	1. <div style="width:100%;height:0;padding-bottom:67%;position:relative;"><iframe src="https://giphy.com/embed/lQfpbII5YaWJE1y5xR" width="100%" height="100%" style="position:absolute" frameBorder="0" class="giphy-embed" allowFullScreen></iframe></div><p><a href="https://giphy.com/gifs/kanyewest-kanye-west-love-lockdown-lQfpbII5YaWJE1y5xR">via GIPHY</a></p>
	2. <div style="width:100%;height:0;padding-bottom:100%;position:relative;"><iframe src="https://giphy.com/embed/kEtm4mSTbxvH7j3uCu" width="100%" height="100%" style="position:absolute" frameBorder="0" class="giphy-embed" allowFullScreen></iframe></div><p><a href="https://giphy.com/gifs/patriotact-netflix-hasan-minhaj-patriot-act-kEtm4mSTbxvH7j3uCu">via GIPHY</a></p>
	3. <div style="width:100%;height:0;padding-bottom:47%;position:relative;"><iframe src="https://giphy.com/embed/A1SxC5HRrD3MY" width="100%" height="100%" style="position:absolute" frameBorder="0" class="giphy-embed" allowFullScreen></iframe></div><p><a href="https://giphy.com/gifs/failure-A1SxC5HRrD3MY">via GIPHY</a></p>
	4. <div style="width:100%;height:0;padding-bottom:75%;position:relative;"><iframe src="https://giphy.com/embed/li0dswKqIZNpm" width="100%" height="100%" style="position:absolute" frameBorder="0" class="giphy-embed" allowFullScreen></iframe></div><p><a href="https://giphy.com/gifs/fail-black-and-white-bob-dylan-li0dswKqIZNpm">via GIPHY</a></p>

